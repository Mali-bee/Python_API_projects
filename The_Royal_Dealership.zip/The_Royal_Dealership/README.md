The Royal Dealership

A Python Flask API project focused on managing high-end luxury car inventory. This is a beginner-level project I built to get more comfortable with Python APIs and Flask development.

What It Does
The Royal Dealership is basically a digital inventory system for luxury cars. It lets you store and manage information about high-end vehicles, keeping track of all the essential details you'd want to know about each car. Nothing too complicated - just a straightforward way to practice working with APIs while dealing with something more interesting than generic todo lists.
The system handles all the core car information you'd expect: make, model, year, color, and fuel type. I built this to get hands-on experience with Flask routing, data handling, and structuring a proper API that could actually be useful in a real-world scenario.
Features

Store luxury car information (make, model, year, color, fuel type)
RESTful API endpoints for managing inventory
Built with Flask for clean, simple routing
Runs in a virtual environment for clean dependency management


Tech Stack

Python - Core programming language
Flask - Web framework for the API
Virtual Environment - For dependency isolation


Getting Started

Clone the repository
Set up a virtual environment:
bashpython -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

Install dependencies:
bashpip install -r requirements.txt

Run the application:
bashpython app.py


Learning Goals
This project helped me practice:

Flask API development
Working with virtual environments
Structuring data models
Creating RESTful endpoints
JSON data handling

Perfect stepping stone for more complex API projects!