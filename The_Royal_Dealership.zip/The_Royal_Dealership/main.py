#system that houses and lists luxury car brands for sale :-D
#this is a beginner friendly Python REST API project built with flask
#brought to you by Malibongwe Makhubo


from flask import Flask, jsonify, request                               #using Flask framework | to convert to json file | to perform CRUD; GET, POST, PUT, DELETE
from flask_sqlalchemy import SQLAlchemy                                 #using the framework to import the ORM - object relational mapper, this makes it so python works with the databse without having to write SQl


app = Flask(__name__)                                                   #flask object initialise to app


#set up the database
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///automobiles.db"      

db = SQLAlchemy(app)                                                    #database object, initialezed to the Flask application


class LuxuryBrands(db.Model):
    id = db.Column(db.Integer, primary_key=True)                        #first column of the database, the id (also it being the primary key)
    make = db.Column(db.String, nullable=False)                         #nullable=False means it can't be empty                           
    model = db.Column(db.String, nullable=False) 
    year = db.Column(db.Integer, nullable=False)
    colour = db.Column(db.String, nullable=False)
    fuel_type = db.Column(db.String)
    
    def to_dict(self):                                                   #convert the information into a python dictionary so that it can convert to Json 
        return {
            "id" : self.id,
            "make" : self.make,
            "model" : self.model,
            "year" : self.year,
            "colour" : self.colour,
            "fuel_type" : self.fuel_type
        }
    
with app.app_context():
    db.create_all()


#routes
@app.route("/")                                                         #setting the URI routes through the flask decorator
def home():
    return jsonify({"message":"Welcome to The Royal Luxury Automobiles"})


#GET - READ (R)
@app.route("/automobiles/", methods=["GET"])                            #to get all information
def get_cars():
    automobiles = LuxuryBrands.query.all()                              #to call the class and use it to extract key terms for information 
    
    return jsonify([cars.to_dict() for cars in automobiles])            #loop through all the available information

@app.route("/automobiles/<int:automobile_id>", methods=["GET"])         #to get singular information
def get_car(automobile_id):
    automobile = LuxuryBrands.query.get(automobile_id)
    if automobile:
        return jsonify(automobile.to_dict())
    else:
        return jsonify({"error":"Automobile not found"}), 404           #error handling


#POST - CREATE (C)
@app.route("/automobiles/", methods=["POST"])
def add_cars():
    data = request.get_json()                                           #receive the json file and initialise it to the data variable
    
    new_car = LuxuryBrands(                                             #mapping the key terms for submitting new informatino
        make=data["make"],
        model=data["model"],
        year=data["year"],
        colour=data["colour"],
        fuel_type=data["fuel_type"]
        )
    
    db.session.add(new_car)                                             #append new information to the database
    db.session.commit()                                                 #anytime you do anything to database, commit it.
    
    return jsonify(new_car.to_dict()),201                               #when all is done, remember to convert the  new information into a python dictionary so that it can then convert into a json file to pass through the API


#PUT - UPDATE (U)
@app.route("/automobiles/<int:automobile_id>", methods=["PUT"])
def update_cars(automobile_id):
    data = request.get_json()
    
    automobile = LuxuryBrands.query.get(automobile_id)
    if automobile:
        automobile.make = data.get("make", automobile.make)
        automobile.model = data.get("model", automobile.model)
        automobile.year = data.get("year", automobile.year)
        automobile.colour = data.get("colour", automobile.colour)
        automobile.fuel_type = data.get("fuel_type", automobile.fuel_type)
        
        db.session.commit()
    
        return jsonify(automobile.to_dict()), 200
    
    else:
        return jsonify({"error":"Automobile not found"}), 404
    
    
#DELETE (D)
@app.route("/automobiles/<int:automobile_id>", methods=["DELETE"])
def delete_car(automobile_id):
    data = request.get_json()
    
    automobile = LuxuryBrands.query.get(automobile_id)
    if automobile:
        db.session.delete(automobile)                                   #delete row from database
        db.session.commit()
        
        return jsonify({"messgae":"Luxury automobile has been removed from the database"})
    
    else:
        return jsonify({"error":"Automobile nor found"}), 404
    
    





if __name__ == ("__main__"):
    app.run(debug=True)                                                 

